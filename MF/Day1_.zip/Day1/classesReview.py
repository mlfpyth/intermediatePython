print(type(5))
print(type("python"))
print(type([1, 2, 3]))
print(type(x*x for x in [2, 3, 4]))