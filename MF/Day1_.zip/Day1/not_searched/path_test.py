def found():
    print("Python found me")
    # In Windows
    # Set-Item Env:PYTHONPATH "not_searched"